import sys

for _ in range(10**6):
    sys.stdin.readline().rstrip()