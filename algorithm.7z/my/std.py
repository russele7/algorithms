print(sum(map(int, input().split())))
