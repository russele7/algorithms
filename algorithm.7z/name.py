import sys

name = sys.stdin.readline().rstrip()  # Применим readline().
print(f'Привет, {name}!') 